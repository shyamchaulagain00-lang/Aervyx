﻿# Aervyx v1.0.0

Thank you for downloading Aervyx.

Place your Aervyx executable inside this archive.
For support, join our Discord: https://discord.gg/M7pD8FnSe
